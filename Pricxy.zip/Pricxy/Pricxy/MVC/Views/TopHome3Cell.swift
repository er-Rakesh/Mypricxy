//
//  TopHome3Cell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/21/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class TopHome3Cell: UICollectionViewCell {
 
    @IBOutlet weak var itemimagethree: UIImageView!
    @IBOutlet weak var itemimagenamethree: UILabel!
}
