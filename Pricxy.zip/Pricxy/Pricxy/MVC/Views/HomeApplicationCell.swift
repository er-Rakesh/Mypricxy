//
//  HomeApplicationCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/16/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class HomeApplicationCell: UITableViewCell
{

    @IBOutlet weak var Imageview: UIImageView!
    @IBOutlet weak var imageLabel: UIImageView!
    @IBOutlet weak var aboutlabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
