//
//  VoucharCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/21/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class VoucharCell: UICollectionViewCell {
    
    @IBOutlet weak var Voucharimageview: UIImageView!
    @IBOutlet weak var voucharName: UILabel!
    @IBOutlet weak var voucharView: UIView!

       override func awakeFromNib()
       {
      super.awakeFromNib()
        
               voucharView.layer.shadowColor = UIColor.black.cgColor
               voucharView.layer.shadowOpacity = 5
               voucharView.layer.shadowOffset = .zero
               voucharView.layer.shadowRadius = 5
}
}
