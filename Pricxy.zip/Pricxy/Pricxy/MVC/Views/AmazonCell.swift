//
//  AmazonCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class AmazonCell: UITableViewCell {

    @IBOutlet weak var Amazonimage: UIImageView!
    @IBOutlet weak var companeyalogo: UIImageView!
    @IBOutlet weak var Aboutproduct: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
