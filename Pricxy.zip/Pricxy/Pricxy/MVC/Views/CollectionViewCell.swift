//
//  CollectionViewCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/22/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageview: UIImageView!
    
    override func awakeFromNib() {
    super.awakeFromNib()
    }
}
