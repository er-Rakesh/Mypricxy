//
//  TopHome2Cell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/21/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class TopHome2Cell: UICollectionViewCell {
    
    @IBOutlet weak var itemimagesecont: UIImageView!
    @IBOutlet weak var itemimagenamesecong: UILabel!
}
