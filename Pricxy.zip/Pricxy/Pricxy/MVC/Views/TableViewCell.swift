//
//  TableViewCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/22/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit
import LGSideMenuController

class TableViewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{

    var imageArray: NSMutableArray = ["home (2)", "aeroplane (2)", "Electronics (2)", "Groccery (2)", "Health (2)", "cabs (2)","gift(2)","Fashion (2)","baby (2)","Service (2)","other (2)",]

    
    
    @IBOutlet weak var Collectionview: UICollectionView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.Collectionview.delegate = self
        self.Collectionview.dataSource = self
    //var imageArray = [String] ()
    

    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return imageArray.count
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return 10
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell: CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectioncell", for: indexPath) as? CollectionViewCell
    {
    let randomNumber = Int(arc4random_uniform(UInt32(imageArray.count)))
        cell.imageview.image = UIImage(named: imageArray[randomNumber] as! String)
    return cell
    }
    return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
       // return CGSize(width: self.Collectionview.frame.size.width/4-20, height: 120)
        let size = CGSize(width: 120, height: 120)
         return size
    }
    
    }



