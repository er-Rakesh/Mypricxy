//
//  NotificationCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class NotificationCell: UITableViewCell {

    @IBOutlet weak var notificationimage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
               notificationimage.layer.shadowColor = UIColor.black.cgColor
               notificationimage.layer.shadowOpacity = 1
               notificationimage.layer.shadowOffset = .zero
               notificationimage.layer.cornerRadius = 5
               notificationimage.layer.shadowRadius = 5
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
