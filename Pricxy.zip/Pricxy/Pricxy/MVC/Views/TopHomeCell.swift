//
//  TopHomeCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/21/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class TopHomeCell: UICollectionViewCell {
    
    @IBOutlet weak var itemimageview: UIImageView!
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var viewone: UIView!
    
}
