//
//  LGsidemenuCell.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class LGsidemenuCell: UITableViewCell {

    @IBOutlet weak var imagelgside: UIImageView!
    @IBOutlet weak var labelnamelgside: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
