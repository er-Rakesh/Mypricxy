//
//  LGsidemenuVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class LGsidemenuVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tableSetting: UITableView!
    var arraylgimage: NSMutableArray = ["share (2)","rate (2)","privacy policy (2)","term and condition (2)","contact (2)","request (2)","about (2)","logout (2)",]
    var arraylgname: NSMutableArray = ["SHARE","RATE","PRIVACY POLICY","TERM AND CONDITION","CONTACT","REQUEST","ABOUT","LOGOUT",]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableSetting.tableFooterView = UIView()

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arraylgimage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {

        let cell = tableView.dequeueReusableCell(withIdentifier: "menu", for: indexPath) as! LGsidemenuCell
        cell.selectionStyle = .none
        cell.labelnamelgside.text = arraylgname.object(at: indexPath.row) as? String
        cell.imagelgside.image = UIImage.init(named:arraylgimage.object(at: indexPath.row)as! String)
        cell.selectionStyle = .none

                     return cell
          }
          func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
              return 50
          }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        CellAnimator.animateTableViewCell(cell, withDuration: 0.5, animation: CellAnimator.AnimationType(rawValue: 5)!) //3 and 5 are good options
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
       
        tableSetting.deselectRow(at: indexPath, animated: true)
        _ = sideMenuController?.rootViewController as! UITabBarController

    }
    }


