//
//  HomeVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/16/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class HomeVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    var arrayimage:NSMutableArray = ["bottel","lunch box","watch","bag","lunch box","bottel"]
    var arrayimagelabel:NSMutableArray = ["amazon","flipkart","3x","1x","2x","3x","bottel"]
    var arrayaboutlabel:NSMutableArray = ["adssdhgfghjghkjhjljlk","dfgdhgghfj","ghfdd","trdrdfgxfgh"]

    @IBOutlet weak var tableSetting: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableSetting.tableFooterView = UIView()

    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayimage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "table", for: indexPath) as! HomeApplicationCell
        cell.Imageview.image = UIImage.init(named: arrayimage.object(at: indexPath.row)as! String)
        cell.imageLabel.image = UIImage.init(named: arrayimagelabel.object(at: indexPath.row)as! String)
       // cell.aboutlabel.text = arrayaboutlabel.object(at: indexPath.row) as? String
       
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 170
    }
    

    @IBAction func backButtonTapped(_ sender: Any)
    {
        self.dismiss(animated: true)

    }
}
