//
//  TopHomeVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/21/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit
import LGSideMenuController
class TopHomeVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout
{
   
    
    @IBOutlet weak var collectionSetting: UICollectionView!
    
    let arrayitemImages:NSMutableArray = ["image", "bag", "01", "video-tips",]
    let arrayitemname:NSMutableArray = ["ABOUT", "APPOINTMENT", "PROFILE", "VIDEO TIPS",]
    
    let arrayitemImagessecond:NSMutableArray = ["image", "bag", "01", "video-tips",]
    let arrayitemnamesecond:NSMutableArray = ["ABOUT", "APPOINTMENT", "PROFILE", "VIDEO TIPS",]
    
    let arrayitemImagesthree:NSMutableArray = ["image", "bag", "01", "video-tips",]
    let arrayitemnamethree:NSMutableArray = ["ABOUT", "APPOINTMENT", "PROFILE", "VIDEO TIPS",]
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
   /* func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {

            let view = UIView()
            view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 40)
            view.backgroundColor = UIColor.init(red: 245/255.0, green: 245/255.0, blue: 245/255.0, alpha: 1.0)
            
            
            let label = UILabel()
            label.frame = CGRect(x: 10, y: 0, width: 100, height: 40)
            label.text = "27 March 2019"
            label.backgroundColor = UIColor.clear
            
            view.addSubview(label)
        
            return view
            
        }*/
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return arrayitemImages.count
        return arrayitemImagessecond.count
        return arrayitemImagesthree.count
        
       }
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
           
                  if indexPath.row == 0
                  {
                      
                      let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "one", for: indexPath) as! TopHomeCell
                      
                      cell.itemimageview.image = UIImage.init(named: arrayitemImages.object(at: indexPath.row) as! String)
                      cell.itemName.text = arrayitemname.object(at: indexPath.row) as? String
                      return cell
                    
                  }
                  else
                  
                    if indexPath.row == 1
                    {

                        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "two", for: indexPath) as! TopHome2Cell
                    
                    cell.itemimagesecont.image = UIImage.init(named: arrayitemImagessecond.object(at: indexPath.row) as! String)
                    cell.itemimagenamesecong.text = arrayitemnamesecond.object(at: indexPath.row) as? String
                    return cell
                  }
            
                else
                  {
                    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "three", for: indexPath) as! TopHome3Cell
                      
                      cell.itemimagethree.image = UIImage.init(named: arrayitemImagesthree.object(at: indexPath.row) as! String)
                      cell.itemimagenamethree.text = arrayitemnamethree.object(at: indexPath.row) as? String
                      return cell
                  }
        
        func collectionView(_: UICollectionView, layout: UICollectionViewLayoutAttributes, referenceSizeForHeaderInSection: Int)
        {
            
            let view = UIView()
            view.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 40)
            view.backgroundColor = UIColor.init(red: 245/255.0, green: 245/255.0, blue: 245/255.0, alpha: 1.0)
            
            
            let label = UILabel()
            label.frame = CGRect(x: 10, y: 0, width: 100, height: 40)
            label.text = "27 March 2019"
            label.backgroundColor = UIColor.clear
            
            
            
            view.addSubview(label)
            
            
           // return view
            
        }
        
        
        
           
           func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
           {
               return CGSize(width: self.collectionSetting.frame.size.width/4-20, height: 120)
           }

           func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
              {
                  CellAnimator.animateCollectionViewCell(cell, withDuration: 0.5, animation: CellAnimator.AnimationType(rawValue: 5)!) //3 and 5 are good options
              }
 
    }
    
    @IBAction func backbuttonTapped(_ sender: Any) {
      //  let vcObject = self.storyboard?.instantiateViewController(withIdentifier: "TopHomeVC")
       // let navigation = myNavigationController.viewControllers![myNavigationController.selectedIndex] as! UINavigationController
                  // navigation.pushViewController(vcObject!, animated: false)
         sideMenuController?.showLeftViewAnimated()

    }
    
    @IBAction func morebuttonTapped(_ sender: Any) {
    }

    @IBAction func notificationTapped(_ sender: Any) {
    }
    
    @IBAction func menubuttonTapped(_ sender: Any)
    {
   
        

}
}
