//
//  myPrixcyVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class myPrixcyVC: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    var arrayimageprixcy: NSMutableArray = ["amazon","flipkart","3x","1x","2x",]
    var arraylabelname:NSMutableArray = ["Amazon","flipakard","sanpdeal","Amazon","sanpdeal"]
    var arrayabout:NSMutableArray = ["ghejgfahjsdgfhjd ghasghjsghdjsf hdsfhg sg","sdhsgajdghjsgf","dyfdgsdfhdgsfj  dfghjdgf hjg fdghjsayufagduyg","dgfjsgd  dfdsgf hgd gkdgs fdfg jfg","dhg dgfjdhsg fdhj dsgf dg dshd ffsdyjrgsgfy",]
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayimageprixcy.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "prixcy", for: indexPath) as! MyPrixcyCell
               cell.selectionStyle = .none
               cell.labelPraxcy.text = arraylabelname.object(at: indexPath.row) as? String
               cell.aboutPreaxccy.text = arrayabout.object(at: indexPath.row) as? String
               cell.prixcyImage.image = UIImage.init(named:arrayimageprixcy.object(at: indexPath.row)as! String)
               return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    
    @IBAction func ManuButtonTapped(_ sender: Any)
    {
        sideMenuController?.showLeftViewAnimated()
    }
    
}
