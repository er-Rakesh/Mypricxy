//
//  VoucharDealsVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/21/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit
import LGSideMenuController

class VoucharDealsVC: UIViewController, UICollectionViewDelegateFlowLayout,UICollectionViewDelegate, UICollectionViewDataSource {
    
    let arrayVoucharImages:NSMutableArray = ["home (2)", "aeroplane (2)", "Electronics (2)", "Groccery (2)", "Health (2)", "cabs (2)","gift(2)","Fashion (2)","baby (2)","Service (2)","other (2)",]
       let arrayVoucharname:NSMutableArray = ["Home", "Travel", "Electronics", "Groccery", "Health", "Cabs","Gift","Fashion","Baby","Service","Other",]
    
        
    
    @IBOutlet weak var collectionSetting: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      let voucharview = UIView()
              voucharview.layer.shadowColor = UIColor.black.cgColor
              voucharview.layer.shadowOpacity = 5
        voucharview.layer.shadowOffset = .zero
              voucharview.layer.shadowRadius = 10

    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrayVoucharImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "vouchar", for: indexPath) as! VoucharCell
        
        cell.Voucharimageview.image = UIImage.init(named: arrayVoucharImages.object(at: indexPath.row) as! String)
        cell.voucharName.text = arrayVoucharname.object(at: indexPath.row) as? String
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return CGSize(width: self.collectionSetting.frame.size.width/4-20, height: 90)
    }

    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
       {
           CellAnimator.animateCollectionViewCell(cell, withDuration: 0.5, animation: CellAnimator.AnimationType(rawValue: 5)!) //3 and 5 are good options
       }
    
    @IBAction func backButtonTapped(_ sender: Any)
    {
       
        navigationController?.popViewController(animated: true)
    }
}
