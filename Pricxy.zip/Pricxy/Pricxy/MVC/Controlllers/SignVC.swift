import UIKit

class SignVC: UIViewController
{
    //MARK:- IBOutlets
    
    @IBOutlet weak var enternumberTextfield: UITextField!
    //MARK:- Properties
    
    //MARK:- View Lifecycle
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    //MARK:- IBActions
    
    @IBAction func verifyButtonTapped(_ sender: Any)
    {
    }
    @IBAction func facebookButtonTapped(_ sender: Any) {
    }
    @IBAction func twitterbuttonTapped(_ sender: Any) {
    }
    @IBAction func skipButtonTapped(_ sender: Any) {
    }
    //MARK:- Custom Methods
}


