//
//  AmazonVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class AmazonVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    var arrayAmzonimage:NSMutableArray = ["bag","lunch box","bottel","bag","lunch box","bottel",]
    var arrayProductimage:NSMutableArray = ["amazon","flipkart","3x","1x","2x","3x",]
    var arrayaboutproduct:NSMutableArray = ["adssdh hjsaghdge hghjsgdj asgdhjgfgh","hsgafh wggasjhgd fdsgjhdsg dsj  shjdghjsajgsdhjfg dfg","jghkj sagsgf gsfjsgshjgfs hjf shjljlk","dfgdhg qweghjegfg dshjfgds fgdshjgfghfj","ghfduiercue urehuire iuceiurcyeiuyeiuyt cyud","trdrdfg ewriuceuryceouwcr eryco xfgh",]

    @IBOutlet weak var tableSetting: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableSetting.tableFooterView = UIView()

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return arrayAmzonimage.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
      let cell = tableView.dequeueReusableCell(withIdentifier: "amazon", for: indexPath) as! AmazonCell
        
               cell.Amazonimage.image = UIImage.init(named: arrayAmzonimage.object(at: indexPath.row)as! String)
               cell.companeyalogo.image = UIImage.init(named: arrayProductimage.object(at: indexPath.row)as! String)
               cell.Aboutproduct.text = arrayaboutproduct.object(at: indexPath.row) as? String
               cell.selectionStyle = .none

               return cell
               
           }
           func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
               return 150
           }
    
     func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
    {
        CellAnimator.animateTableViewCell(cell, withDuration: 0.5, animation: CellAnimator.AnimationType(rawValue: 5)!) //3 and 5 are good options
    }
           
    @IBAction func backButtonTapped(_ sender: Any)
    {
        self.dismiss(animated: true) 

    }
}
    


