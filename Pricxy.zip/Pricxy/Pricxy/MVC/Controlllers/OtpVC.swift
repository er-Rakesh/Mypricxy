//
//  OtpVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/15/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class OtpVC: UIViewController {

   
        //MARK:- IBOutlets
        
    
        //MARK:- Properties
        
        //MARK:- View Lifecycle
        override func viewDidLoad()
        {
            super.viewDidLoad()
            
        }
        
        //MARK:- IBActions
    @IBAction func submitbuttonTapped(_ sender: Any) {
    }
    
        //MARK:- Custom Methods
    }


