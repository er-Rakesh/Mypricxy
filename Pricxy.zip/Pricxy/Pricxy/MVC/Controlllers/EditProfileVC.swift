//
//  EditProfileVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/16/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class EditProfileVC: UIViewController {

    
        //MARK:- IBOutlets
    @IBOutlet weak var nametextfielf: UITextField!
    
    @IBOutlet weak var numberTextfielf: UITextField!
    @IBOutlet weak var emiailtextfield: UITextField!
    @IBOutlet weak var professionaltextfield: UITextField!
    @IBOutlet weak var dateyearstextfield: UITextField!
    //MARK:- Properties
        
        //MARK:- View Lifecycle
        override func viewDidLoad()
        {
            super.viewDidLoad()
            
        }
        
        //MARK:- IBActions
    @IBAction func editNameTapped(_ sender: Any) {
    }
    @IBAction func numberEditTapped(_ sender: Any) {
    }
    @IBAction func emailTapped(_ sender: Any) {
    }
    @IBAction func professionalTapped(_ sender: Any) {
    }
    @IBAction func maleTapped(_ sender: Any) {
    }
    @IBAction func femaleTapped(_ sender: Any) {
    }
    @IBAction func ddmmyybuttonTapped(_ sender: Any) {
    }
    @IBAction func backButtonTapped(_ sender: Any)
    {
        //self.dismiss(animated: true)
        navigationController?.popViewController(animated: true)

    }
    
    @IBAction func updateButtonTapped(_ sender: Any) {
    }
    //MARK:- Custom Methods
    }


