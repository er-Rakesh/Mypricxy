//
//  ForgetPasswordVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/25/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class ForgetPasswordVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func backbuttonTapped(_ sender: Any)
    {
        self.dismiss(animated: true) {
            
        }
       // navigationController?.popViewController(animated: true)
    }
    
    

}
