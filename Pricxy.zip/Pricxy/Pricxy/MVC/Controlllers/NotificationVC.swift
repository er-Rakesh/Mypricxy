//
//  NotificationVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class NotificationVC: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    var arraynotifivation: NSMutableArray = ["image-1","image-1","image-1","image-1","image-1","image-1",]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arraynotifivation.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
     let cell = tableView.dequeueReusableCell(withIdentifier: "notification", for: indexPath) as! NotificationCell
               
                      cell.notificationimage.image = UIImage.init(named: arraynotifivation.object(at: indexPath.row)as! String)
                      cell.selectionStyle = .none

                      return cell
                      
                  }
                  func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
                      return 150
                  }
           
            func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath)
           {
               CellAnimator.animateTableViewCell(cell, withDuration: 0.5, animation: CellAnimator.AnimationType(rawValue: 5)!) //3 and 5 are good options
           }
   
    @IBAction func backbuttonTapped(_ sender: Any)
    {
        navigationController?.popViewController(animated: true)
    }
   
    
    @IBAction func allbuttonTapped(_ sender: Any) {
    }
    @IBAction func SpecialforyouTapped(_ sender: Any) {
    }
    
    
    
}


