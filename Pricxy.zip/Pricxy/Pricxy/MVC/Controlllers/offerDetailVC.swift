//
//  offerDetailVC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/19/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class offerDetailVC: UIViewController {

    
        //MARK:- IBOutlets
    
    
    
   
    //MARK:- Properties
        
        //MARK:- View Lifecycle
        override func viewDidLoad()
        {
            super.viewDidLoad()
            
        }
        
        //MARK:- IBActions
    @IBAction func backbuttonTapped(_ sender: Any)
    {
        navigationController?.popViewController(animated: true)

    }
    
    @IBAction func copyButtonTapped(_ sender: Any) {
    }
    //MARK:- Custom Methods
    @IBAction func getofferTapped(_ sender: Any) {
    }
    @IBAction func ExpationTapped(_ sender: Any) {
    }
}


