//
//  Offerdetails2VC.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/22/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class Offerdetails2VC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
