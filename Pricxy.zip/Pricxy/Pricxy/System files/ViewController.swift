//
//  ViewController.swift
//  Pricxy
//
//  Created by Rakesh Kumawat on 11/15/19.
//  Copyright © 2019 Rakesh Kumawat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

